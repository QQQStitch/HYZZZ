#coding:utf8
from setuptools import setup

setup(
    name='1520974zsy',
    version='1.0',
    packages=['myapp']

    )
