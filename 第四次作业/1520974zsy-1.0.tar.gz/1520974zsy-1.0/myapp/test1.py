def Prime(n):
    if n<2:
        return False
    if n==2:
        return True
    else:
        for i in range(2,n):
            if(n%i)==0:
                return "FALSE"
            else:
                return "TRUE"

n=int(input("Please input a number："))
print(Prime(n))
