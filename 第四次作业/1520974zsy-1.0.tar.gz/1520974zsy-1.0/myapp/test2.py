import string
s=input('请输入一串字符:')

c_num=0
a_num = 0
spac_num = 0
dgt_num = 0
oth_num = 0

for c in s:
    if c in string.ascii_letters:
        a_num +=1
    elif c.isdigit():
        dgt_num +=1
    elif c.isspace():
        spac_num +=1
    elif c in string.punctuation:
        oth_num +=1
    else:
        c_num +=1

print('中文字符有：%d'%c_num)
print('英文字符有：%d' %a_num)
print('数字有：%d'%dgt_num)
print('空格有：%d'%spac_num)
print('其他字符有：%d'%oth_num)
