import sys


def countdiff(a):
        digit=0
        eng=0
        chi=0
        space=0
        other=0
        for i in a:
                if i.isdigit():
                        digit+=1
                elif i.isalpha():
                        eng+=1
                elif check_contain_chinese(i):
                        chi+=1
                elif i.isspace():
                        space+=1
                else:
                        other+=1
        print('数字%d个，英语字符%d个，中文字符%d个，空格%d个，其他字符%d个'%(digit,eng,chi,space,other))

def check_contain_chinese(check_str):
        for ch in check_str.decode('utf-8'):
                if u'\u4e00' <= ch <= u'\u9fff':
                        return True
                else:
                        return False
