def Prime(n):
    flag=0
    if n==1:
        flag=0
    elif n==2:
        flag=0
    else:
        for i in range (2,n-1):
            if n%i==0:
                flag=1
                break

    print('%d'%(flag))
    if(flag==0):
        return True
    else:
	return False
